# main.py

# Import the classes from the other files
from policyholder import Policyholder
from product import Product
from payment import Payment


# -------------------------------
# STEP 1: Create a product
# -------------------------------

# Create one insurance product
product1 = Product("PR001", "Health Insurance", 5000)


# -------------------------------
# STEP 2: Create policyholders
# -------------------------------

# Create two policyholders
policyholder1 = Policyholder("PH001", "John Mwangi", 35)
policyholder2 = Policyholder("PH002", "Mary Wanjiku", 29)


# -------------------------------
# STEP 3: Register products
# -------------------------------

# Assign the product to both policyholders
policyholder1.register_product(product1)
policyholder2.register_product(product1)


# -------------------------------
# STEP 4: Create payments
# -------------------------------

# Create payment records for both policyholders
payment1 = Payment("PAY001", policyholder1, product1, 5000)
payment2 = Payment("PAY002", policyholder2, product1, 5000)


# -------------------------------
# STEP 5: Process payments
# -------------------------------

# Process both payments
payment1.process_payment()
payment2.process_payment()

# Add payments to each policyholder
policyholder1.add_payment(payment1)
policyholder2.add_payment(payment2)


# -------------------------------
# STEP 6: Display account details
# -------------------------------

# Display details for both policyholders
print("=== POLICYHOLDER 1 DETAILS ===")
policyholder1.display_details()

print("=== POLICYHOLDER 2 DETAILS ===")
policyholder2.display_details()