# product.py

# This class represents an insurance product (e.g., Health, Motor, Life)
class Product:

    # This method runs when a new product is created
    def __init__(self, product_id, product_name, price):
        self.product_id = product_id
        self.product_name = product_name
        self.price = price
        self.status = "Active"   # By default, product is active

    # This method updates the product name and/or price
    def update_product(self, new_name=None, new_price=None):
        # Check if a new name was provided
        if new_name is not None:
            self.product_name = new_name

        # Check if a new price was provided
        if new_price is not None:
            self.price = new_price

    # This method suspends (deactivates) the product
    def suspend_product(self):
        self.status = "Suspended"

    # This method reactivates the product
    def activate_product(self):
        self.status = "Active"

    # This method displays product details
    def display_product(self):
        print("Product Details")
        print("----------------")
        print("Product ID:", self.product_id)
        print("Product Name:", self.product_name)
        print("Price:", self.price)
        print("Status:", self.status)
        print("\n")
        