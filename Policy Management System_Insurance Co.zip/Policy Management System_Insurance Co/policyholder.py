# This class represents a policyholder in the insurance system
class Policyholder:

    # This method runs automatically when a new policyholder is created
    def __init__(self, policyholder_id, name, age):
        self.policyholder_id = policyholder_id
        self.name = name
        self.age = age
        self.status = "Active"
        self.products = []
        self.payments = []

    # This method adds/registers a new product for the policyholder
    def register_product(self, product):
        self.products.append(product)

    # This method suspends the policyholder
    def suspend_policyholder(self):
        self.status = "Suspended"

    # This method reactivates the policyholder
    def reactivate_policyholder(self):
        self.status = "Active"

    # This method adds a payment record for the policyholder
    def add_payment(self, payment):
        self.payments.append(payment)

    # This method displays the policyholder's account details
    def display_details(self):
        print("Policyholder Account Details")
        print("-----------------------------")
        print("Policyholder ID:", self.policyholder_id)
        print("Name:", self.name)
        print("Age:", self.age)
        print("Status:", self.status)

        print("\nRegistered Products:")
        if len(self.products) == 0:
            print("No products registered.")
        else:
            for product in self.products:
                print("-", product.product_name)

        print("\nPayment Records:")
        if len(self.payments) == 0:
            print("No payments made.")
        else:
            for payment in self.payments:
                print("-", payment.amount, "paid for", payment.product.product_name)

        print("\n")
        # This method returns the policyholder's account details as a dictionary
      
        