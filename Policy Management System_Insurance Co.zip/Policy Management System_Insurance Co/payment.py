# payment.py

# This class represents a payment made by a policyholder
class Payment:

    # This method runs when a new payment is created
    def __init__(self, payment_id, policyholder, product, amount):
        self.payment_id = payment_id
        self.policyholder = policyholder   # who made the payment
        self.product = product             # product being paid for
        self.amount = amount               # amount paid
        self.status = "Pending"            # default status before processing
        self.penalty = 0                   # default penalty is 0

    # This method processes the payment
    def process_payment(self):
        # Simple check: if amount is greater than 0, mark as completed
        if self.amount > 0:
            self.status = "Completed"
            print("Payment processed successfully.")
        else:
            print("Invalid payment amount.")

    # This method sends a payment reminder
    def send_reminder(self):
        print("Reminder: Payment for", self.product.product_name,
              "is due for", self.policyholder.name)

    # This method applies a penalty for late payment
    def apply_penalty(self, penalty_amount):
        self.penalty = penalty_amount
        print("Penalty of", penalty_amount, "applied.")

    # This method displays payment details
    def display_payment(self):
        print("Payment Details")
        print("----------------")
        print("Payment ID:", self.payment_id)
        print("Policyholder:", self.policyholder.name)
        print("Product:", self.product.product_name)
        print("Amount Paid:", self.amount)
        print("Penalty:", self.penalty)
        print("Status:", self.status)
        print("\n")